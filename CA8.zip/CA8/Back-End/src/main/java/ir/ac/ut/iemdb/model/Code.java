package ir.ac.ut.iemdb.model;

public class Code {
    String code;
}
