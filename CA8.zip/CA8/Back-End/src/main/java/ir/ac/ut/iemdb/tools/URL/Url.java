package ir.ac.ut.iemdb.tools.URL;

public class Url {
    public static final String movies = "http://138.197.181.131:5000/api/v2/movies";
    public static final String actors = "http://138.197.181.131:5000/api/v2/actors";
    public static final String users = "http://138.197.181.131:5000/api/users";
    public static final String comments = "http://138.197.181.131:5000/api/comments";

    Url() {}
}
