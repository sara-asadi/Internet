package app.tools;

public class Response {
    public static final String OK_RESPONSE = "ok";
}
